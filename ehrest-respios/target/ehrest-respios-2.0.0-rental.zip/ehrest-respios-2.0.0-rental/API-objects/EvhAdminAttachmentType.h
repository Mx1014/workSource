//
// EvhAdminAttachmentType.h
//


///////////////////////////////////////////////////////////////////////////////
// EvhAdminAttachmentType
//
typedef enum {

    EvhAdminAttachmentType_TEXT_REMARK = 0, 
    EvhAdminAttachmentType_LICENSE_NUMBER = 1, 
    EvhAdminAttachmentType_SHOW_CONTENT = 2, 
    EvhAdminAttachmentType_ATTACHMENT = 3

} EvhAdminAttachmentType;

///////////////////////////////////////////////////////////////////////////////

