//
// EvhAddressServiceErrorCode.h
//

#define EvhAddressServiceErrorCode_SCOPE @"address"
#define EvhAddressServiceErrorCode_ERROR_ADDRESS_NOT_EXIST 10001
