//
// EvhActivityLocationScope.h
//


///////////////////////////////////////////////////////////////////////////////
// EvhActivityLocationScope
//
typedef enum {

    EvhActivityLocationScope_ALL = 0, 
    EvhActivityLocationScope_NEARBY = 1, 
    EvhActivityLocationScope_SAME_CITY = 2

} EvhActivityLocationScope;

///////////////////////////////////////////////////////////////////////////////

