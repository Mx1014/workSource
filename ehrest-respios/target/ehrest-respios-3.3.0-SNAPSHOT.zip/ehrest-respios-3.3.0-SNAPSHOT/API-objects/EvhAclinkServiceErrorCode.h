//
// EvhAclinkServiceErrorCode.h
// generated at 2016-04-12 15:02:19 
//

#define EvhAclinkServiceErrorCode_SCOPE @"aclink"
#define EvhAclinkServiceErrorCode_ERROR_ACLINK_DOOR_EXISTS 10001
#define EvhAclinkServiceErrorCode_ERROR_ACLINK_ACTIVING_FAILED 10002
#define EvhAclinkServiceErrorCode_ERROR_ACLINK_DOOR_NOT_FOUND 10003
#define EvhAclinkServiceErrorCode_ERROR_ACLINK_STATE_ERROR 10004
#define EvhAclinkServiceErrorCode_ERROR_ACLINK_PARAM_ERROR 10005
#define EvhAclinkServiceErrorCode_ERROR_ACLINK_USER_NOT_FOUND 10006
#define EvhAclinkServiceErrorCode_ERROR_ACLINK_USER_AUTH_ERROR 10007
