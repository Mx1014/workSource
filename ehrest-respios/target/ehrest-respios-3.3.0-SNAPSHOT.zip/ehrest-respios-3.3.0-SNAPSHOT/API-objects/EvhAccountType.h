//
// EvhAccountType.h
// generated at 2016-04-18 14:48:51 
//

#define EvhAccountType_ACCOUNT_TYPE_SINGLE @"单账号"
#define EvhAccountType_ACCOUNT_TYPE_MULTIPLE @"多账号"

///////////////////////////////////////////////////////////////////////////////

