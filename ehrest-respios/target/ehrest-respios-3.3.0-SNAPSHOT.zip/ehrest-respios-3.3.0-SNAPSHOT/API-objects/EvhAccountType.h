//
// EvhAccountType.h
// generated at 2016-04-12 15:02:18 
//


///////////////////////////////////////////////////////////////////////////////
// EvhAccountType
//
typedef enum {

    EvhAccountType_NONE = 0, 
    EvhAccountType_USER = 1, 
    EvhAccountType_FAMILY = 2, 
    EvhAccountType_ORGANIZATION = 3

} EvhAccountType;

///////////////////////////////////////////////////////////////////////////////

