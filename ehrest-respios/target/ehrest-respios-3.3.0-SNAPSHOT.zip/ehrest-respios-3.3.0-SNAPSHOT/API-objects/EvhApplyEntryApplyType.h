//
// EvhApplyEntryApplyType.h
// generated at 2016-04-12 15:02:20 
//


///////////////////////////////////////////////////////////////////////////////
// EvhApplyEntryApplyType
//
typedef enum {

    EvhApplyEntryApplyType_APPLY = 1, 
    EvhApplyEntryApplyType_EXPANSION = 2, 
    EvhApplyEntryApplyType_RENEW = 3

} EvhApplyEntryApplyType;

///////////////////////////////////////////////////////////////////////////////

