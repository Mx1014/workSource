//
// EvhApplyEntryApplyType.h
// generated at 2016-04-18 14:48:52 
//


///////////////////////////////////////////////////////////////////////////////
// EvhApplyEntryApplyType
//
typedef enum {

    EvhApplyEntryApplyType_APPLY = 1, 
    EvhApplyEntryApplyType_EXPANSION = 2, 
    EvhApplyEntryApplyType_RENEW = 3

} EvhApplyEntryApplyType;

///////////////////////////////////////////////////////////////////////////////

