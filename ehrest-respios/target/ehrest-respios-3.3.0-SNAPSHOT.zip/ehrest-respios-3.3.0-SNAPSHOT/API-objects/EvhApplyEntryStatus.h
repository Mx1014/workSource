//
// EvhApplyEntryStatus.h
// generated at 2016-04-12 15:02:19 
//


///////////////////////////////////////////////////////////////////////////////
// EvhApplyEntryStatus
//
typedef enum {

    EvhApplyEntryStatus_PROCESSING = 1, 
    EvhApplyEntryStatus_RESIDED_IN = 2, 
    EvhApplyEntryStatus_INVALID = 3

} EvhApplyEntryStatus;

///////////////////////////////////////////////////////////////////////////////

