//
// EvhActivityLocalStringCode.h
// generated at 2016-04-12 15:02:19 
//

#define EvhActivityLocalStringCode_SCOPE @"activity"
#define EvhActivityLocalStringCode_ACTIVITY_SIGNUP 1
#define EvhActivityLocalStringCode_ACTIVITY_CHECKIN 2
#define EvhActivityLocalStringCode_ACTIVITY_CONFIRM 3
#define EvhActivityLocalStringCode_ACTIVITY_CANCEL 4
#define EvhActivityLocalStringCode_ACTIVITY_REJECT 5
