//
// EvhApplyParkingCardStatus.h
// generated at 2016-04-12 15:02:19 
//


///////////////////////////////////////////////////////////////////////////////
// EvhApplyParkingCardStatus
//
typedef enum {

    EvhApplyParkingCardStatus_INACTIVE = 0, 
    EvhApplyParkingCardStatus_WAITING = 1, 
    EvhApplyParkingCardStatus_NOTIFIED = 2, 
    EvhApplyParkingCardStatus_FETCHED = 3

} EvhApplyParkingCardStatus;

///////////////////////////////////////////////////////////////////////////////

