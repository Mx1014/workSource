//
// EvhBannerServiceErrorCode.h
// generated at 2016-04-18 14:48:51 
//

#define EvhBannerServiceErrorCode_SCOPE @"banner"
#define EvhBannerServiceErrorCode_ERROR_BANNER_NOT_EXISTS 10001
#define EvhBannerServiceErrorCode_ERROR_BANNER_EXISTS 10002
