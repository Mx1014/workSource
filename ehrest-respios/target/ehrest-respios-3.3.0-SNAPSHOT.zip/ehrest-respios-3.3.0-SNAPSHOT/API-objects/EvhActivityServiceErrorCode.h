//
// EvhActivityServiceErrorCode.h
// generated at 2016-04-12 15:02:19 
//

#define EvhActivityServiceErrorCode_SCOPE @"activity"
#define EvhActivityServiceErrorCode_ERROR_INVALID_ACTIVITY_ID 10000
#define EvhActivityServiceErrorCode_ERROR_INVALID_POST_ID 10001
#define EvhActivityServiceErrorCode_ERROR_INVILID_OPERATION 10002
#define EvhActivityServiceErrorCode_ERROR_INVALID_CONTACT_NUMBER 10003
#define EvhActivityServiceErrorCode_ERROR_INVALID_CONTACT_FAMILY 10004
#define EvhActivityServiceErrorCode_ERROR_INVALID_USER 10005
#define EvhActivityServiceErrorCode_ERROR_INVALID_ACTIVITY_ROSTER 10006
