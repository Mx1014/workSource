//
// EvhAddressAdminStatus.h
// generated at 2016-04-12 15:02:19 
//


///////////////////////////////////////////////////////////////////////////////
// EvhAddressAdminStatus
//
typedef enum {

    EvhAddressAdminStatus_INACTIVE = 0, 
    EvhAddressAdminStatus_CONFIRMING = 1, 
    EvhAddressAdminStatus_ACTIVE = 2

} EvhAddressAdminStatus;

///////////////////////////////////////////////////////////////////////////////

