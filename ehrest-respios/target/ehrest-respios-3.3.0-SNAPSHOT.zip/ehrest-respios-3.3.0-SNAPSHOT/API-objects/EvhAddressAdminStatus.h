//
// EvhAddressAdminStatus.h
// generated at 2016-04-18 14:48:52 
//


///////////////////////////////////////////////////////////////////////////////
// EvhAddressAdminStatus
//
typedef enum {

    EvhAddressAdminStatus_INACTIVE = 0, 
    EvhAddressAdminStatus_CONFIRMING = 1, 
    EvhAddressAdminStatus_ACTIVE = 2

} EvhAddressAdminStatus;

///////////////////////////////////////////////////////////////////////////////

