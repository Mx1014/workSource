//
// EvhBannerGroup.h
// generated at 2016-04-18 14:48:52 
//

#define EvhBannerGroup_DEFAULT @"DEFAULT"
#define EvhBannerGroup_GA @"GA"
#define EvhBannerGroup_BIZ @"BIZ"
#define EvhBannerGroup_PM @"PM"
#define EvhBannerGroup_GARC @"GARC"
#define EvhBannerGroup_GANC @"GANC"
#define EvhBannerGroup_GAPS @"GAPS"

///////////////////////////////////////////////////////////////////////////////

