//
// EvhBannerGroup.h
// generated at 2016-04-12 15:02:19 
//

#define EvhBannerGroup_DEFAULT @"DEFAULT"
#define EvhBannerGroup_GA @"GA"
#define EvhBannerGroup_BIZ @"BIZ"
#define EvhBannerGroup_PM @"PM"
#define EvhBannerGroup_GARC @"GARC"
#define EvhBannerGroup_GANC @"GANC"
#define EvhBannerGroup_GAPS @"GAPS"

///////////////////////////////////////////////////////////////////////////////

