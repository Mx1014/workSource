//
// EvhApplyEntrySourceType.h
// generated at 2016-04-18 14:48:51 
//

#define EvhApplyEntrySourceType_BUILDING @"building"
#define EvhApplyEntrySourceType_MARKET_ZONE @"market_zone"
#define EvhApplyEntrySourceType_FOR_RENT @"for_rent"

///////////////////////////////////////////////////////////////////////////////

