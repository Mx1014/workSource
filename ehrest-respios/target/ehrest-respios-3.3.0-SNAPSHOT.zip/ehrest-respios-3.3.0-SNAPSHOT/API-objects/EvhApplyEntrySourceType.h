//
// EvhApplyEntrySourceType.h
// generated at 2016-04-12 15:02:20 
//

#define EvhApplyEntrySourceType_BUILDING @"building"
#define EvhApplyEntrySourceType_MARKET_ZONE @"market_zone"
#define EvhApplyEntrySourceType_FOR_RENT @"for_rent"

///////////////////////////////////////////////////////////////////////////////

