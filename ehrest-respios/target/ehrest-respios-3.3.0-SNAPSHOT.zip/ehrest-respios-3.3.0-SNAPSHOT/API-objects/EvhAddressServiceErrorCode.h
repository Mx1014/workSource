//
// EvhAddressServiceErrorCode.h
// generated at 2016-04-12 15:02:19 
//

#define EvhAddressServiceErrorCode_SCOPE @"address"
#define EvhAddressServiceErrorCode_ERROR_ADDRESS_NOT_EXIST 10001
