//
// EvhAddressServiceErrorCode.h
// generated at 2016-04-18 14:48:51 
//

#define EvhAddressServiceErrorCode_SCOPE @"address"
#define EvhAddressServiceErrorCode_ERROR_ADDRESS_NOT_EXIST 10001
