//
// EvhApplyEntrySourceType.h
//

#define EvhApplyEntrySourceType_BUILDING @"building"
#define EvhApplyEntrySourceType_MARKET_ZONE @"market_zone"
#define EvhApplyEntrySourceType_FOR_RENT @"for_rent"

///////////////////////////////////////////////////////////////////////////////

