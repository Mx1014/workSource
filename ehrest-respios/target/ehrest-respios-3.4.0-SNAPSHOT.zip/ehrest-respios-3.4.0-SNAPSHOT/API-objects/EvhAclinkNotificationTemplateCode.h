//
// EvhAclinkNotificationTemplateCode.h
//

#define EvhAclinkNotificationTemplateCode_SCOPE @"aclink.notification"
#define EvhAclinkNotificationTemplateCode_ACLINK_NEW_AUTH 1
