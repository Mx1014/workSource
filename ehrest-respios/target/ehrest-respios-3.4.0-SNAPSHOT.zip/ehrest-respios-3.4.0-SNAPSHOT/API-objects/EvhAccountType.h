//
// EvhAccountType.h
//

#define EvhAccountType_ACCOUNT_TYPE_SINGLE @"单账号"
#define EvhAccountType_ACCOUNT_TYPE_MULTIPLE @"多账号"

///////////////////////////////////////////////////////////////////////////////

