#!/bin/sh

./group.sh
./community.sh
./post.sh

